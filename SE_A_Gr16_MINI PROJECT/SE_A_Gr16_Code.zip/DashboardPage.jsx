import React, { useState } from 'react';
import Header from '@/components/Header';
import ProfitGraph from '@/components/ProfitGraph';
import AddTransactionForm from '@/components/AddTransactionForm';
import DailyTransactionsList from '@/components/DailyTransactionsList';

const DashboardPage = () => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleDataChange = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-4 sm:px-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left Column: Graph and Form */}
            <div className="lg:col-span-2 space-y-6">
              <div className="h-96">
                <ProfitGraph refreshTrigger={refreshTrigger} />
              </div>
              <div>
                <AddTransactionForm onTransactionAdded={handleDataChange} />
              </div>
            </div>

            {/* Right Column: Daily List */}
            <div className="lg:col-span-1 h-[calc(100vh-8rem)] lg:sticky lg:top-24">
              <DailyTransactionsList 
                refreshTrigger={refreshTrigger} 
                onTransactionDeleted={handleDataChange}
              />
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;