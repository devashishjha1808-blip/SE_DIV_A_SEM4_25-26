import React, { useState } from 'react';
import { Plus, Trash2, Save } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext';

const AddTransactionForm = ({ onTransactionAdded }) => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [customer, setCustomer] = useState({ name: '', phone: '' });
  const [items, setItems] = useState([
    { itemName: '', costPrice: '', sellingPrice: '', quantity: 1 }
  ]);

  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    newItems[index][field] = value;
    setItems(newItems);
  };

  const addItem = () => {
    setItems([...items, { itemName: '', costPrice: '', sellingPrice: '', quantity: 1 }]);
  };

  const removeItem = (index) => {
    if (items.length > 1) {
      const newItems = items.filter((_, i) => i !== index);
      setItems(newItems);
    }
  };

  const calculateTotals = () => {
    let totalAmount = 0;
    let totalProfit = 0;

    items.forEach(item => {
      const sp = parseFloat(item.sellingPrice) || 0;
      const cp = parseFloat(item.costPrice) || 0;
      const q = parseInt(item.quantity) || 0;

      totalAmount += sp * q;
      totalProfit += (sp - cp) * q;
    });

    return { totalAmount, totalProfit };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      // 1. Handle Customer
      let customerId;
      try {
        // Try to find existing customer by phone
        const existingCustomer = await pb.collection('customers').getFirstListItem(`phone="${customer.phone}" && userId="${currentUser.id}"`, { $autoCancel: false });
        customerId = existingCustomer.id;
      } catch (err) {
        // Create new customer if not found
        const newCustomer = await pb.collection('customers').create({
          name: customer.name,
          phone: customer.phone,
          userId: currentUser.id
        }, { $autoCancel: false });
        customerId = newCustomer.id;
      }

      const { totalAmount, totalProfit } = calculateTotals();
      const now = new Date();

      // 2. Create Transaction
      const transaction = await pb.collection('transactions').create({
        customerId,
        totalAmount,
        totalProfit,
        transactionDate: now.toISOString().split('T')[0] + " 00:00:00.000Z",
        transactionTime: now.toTimeString().split(' ')[0],
        userId: currentUser.id
      }, { $autoCancel: false });

      // 3. Create Transaction Items
      for (const item of items) {
        await pb.collection('transactionItems').create({
          transactionId: transaction.id,
          itemName: item.itemName,
          costPrice: parseFloat(item.costPrice),
          sellingPrice: parseFloat(item.sellingPrice),
          quantity: parseInt(item.quantity),
          userId: currentUser.id
        }, { $autoCancel: false });
      }

      setSuccess('Transaction added successfully!');
      setCustomer({ name: '', phone: '' });
      setItems([{ itemName: '', costPrice: '', sellingPrice: '', quantity: 1 }]);
      if (onTransactionAdded) onTransactionAdded();

      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to add transaction');
    } finally {
      setLoading(false);
    }
  };

  const { totalAmount, totalProfit } = calculateTotals();

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">New Transaction</h2>
      
      {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}
      {success && <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md text-sm">{success}</div>}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700">Customer Name</label>
            <input
              type="text"
              required
              value={customer.name}
              onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
              placeholder="John Doe"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Phone Number</label>
            <input
              type="tel"
              required
              value={customer.phone}
              onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
              placeholder="+1234567890"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-md font-medium text-gray-900">Items</h3>
          </div>
          
          {items.map((item, index) => (
            <div key={index} className="flex flex-wrap gap-3 items-end bg-gray-50 p-3 rounded-md border border-gray-100">
              <div className="flex-1 min-w-[150px]">
                <label className="block text-xs font-medium text-gray-700">Item Name</label>
                <input
                  type="text"
                  required
                  value={item.itemName}
                  onChange={(e) => handleItemChange(index, 'itemName', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
                />
              </div>
              <div className="w-24">
                <label className="block text-xs font-medium text-gray-700">Cost ($)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={item.costPrice}
                  onChange={(e) => handleItemChange(index, 'costPrice', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
                />
              </div>
              <div className="w-24">
                <label className="block text-xs font-medium text-gray-700">Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={item.sellingPrice}
                  onChange={(e) => handleItemChange(index, 'sellingPrice', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
                />
              </div>
              <div className="w-20">
                <label className="block text-xs font-medium text-gray-700">Qty</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={item.quantity}
                  onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm text-gray-900 p-2 border"
                />
              </div>
              {items.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeItem(index)}
                  className="mb-1 p-2 text-red-600 hover:bg-red-50 rounded-md"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              )}
            </div>
          ))}

          <button
            type="button"
            onClick={addItem}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Plus className="h-4 w-4 mr-1" /> Add Item
          </button>
        </div>

        <div className="border-t border-gray-200 pt-4 flex justify-between items-center">
          <div className="text-sm">
            <p className="text-gray-600">Total Amount: <span className="font-bold text-gray-900">${totalAmount.toFixed(2)}</span></p>
            <p className="text-gray-600">Est. Profit: <span className="font-bold text-green-600">${totalProfit.toFixed(2)}</span></p>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {loading ? 'Saving...' : <><Save className="h-4 w-4 mr-2" /> Save Transaction</>}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddTransactionForm;