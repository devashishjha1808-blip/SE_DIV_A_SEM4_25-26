import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { format, subDays, isAfter, startOfDay } from 'date-fns';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const ProfitGraph = ({ refreshTrigger }) => {
  const { currentUser } = useAuth();
  const [timeRange, setTimeRange] = useState('7');
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGraphData = async () => {
      if (!currentUser) return;
      setLoading(true);
      try {
        const days = parseInt(timeRange);
        const startDate = startOfDay(subDays(new Date(), days - 1));
        const startDateStr = startDate.toISOString().split('T')[0];

        const records = await pb.collection('transactions').getFullList({
          filter: `userId = "${currentUser.id}" && transactionDate >= "${startDateStr}"`,
          sort: 'transactionDate',
          $autoCancel: false
        });

        // Group by date
        const profitByDate = {};
        
        // Initialize all dates in range with 0
        for (let i = days - 1; i >= 0; i--) {
          const d = subDays(new Date(), i);
          profitByDate[format(d, 'yyyy-MM-dd')] = 0;
        }

        records.forEach(record => {
          const dateStr = record.transactionDate.split(' ')[0];
          if (profitByDate[dateStr] !== undefined) {
            profitByDate[dateStr] += record.totalProfit;
          }
        });

        const labels = Object.keys(profitByDate).map(d => format(new Date(d), 'MMM dd'));
        const data = Object.values(profitByDate);

        setChartData({
          labels,
          datasets: [
            {
              label: 'Daily Profit ($)',
              data: data,
              borderColor: 'rgb(99, 102, 241)',
              backgroundColor: 'rgba(99, 102, 241, 0.1)',
              fill: true,
              tension: 0.4,
            }
          ]
        });
      } catch (error) {
        console.error("Error fetching graph data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchGraphData();
  }, [timeRange, currentUser, refreshTrigger]);

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '$' + value;
          }
        }
      }
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Profit Overview</h2>
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="block w-32 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
        >
          <option value="7">Last 7 Days</option>
          <option value="15">Last 15 Days</option>
          <option value="30">Last 30 Days</option>
        </select>
      </div>
      <div className="flex-grow relative min-h-[300px]">
        {loading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : (
          <Line options={options} data={chartData} />
        )}
      </div>
    </div>
  );
};

export default ProfitGraph;