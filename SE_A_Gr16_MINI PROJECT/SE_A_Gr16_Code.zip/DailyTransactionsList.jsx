import React, { useState, useEffect } from 'react';
import { Search, ChevronDown, ChevronUp, Trash2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';

const DailyTransactionsList = ({ refreshTrigger, onTransactionDeleted }) => {
  const { currentUser } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [itemsCache, setItemsCache] = useState({});

  const fetchTransactions = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Fetch transactions for today
      const records = await pb.collection('transactions').getFullList({
        filter: `userId = "${currentUser.id}" && transactionDate >= "${today} 00:00:00.000Z"`,
        sort: '-created',
        $autoCancel: false
      });

      // Fetch associated customers to display names/phones
      const customerIds = [...new Set(records.map(r => r.customerId))];
      const customers = {};
      
      if (customerIds.length > 0) {
        const customerRecords = await pb.collection('customers').getFullList({
          filter: customerIds.map(id => `id="${id}"`).join(' || '),
          $autoCancel: false
        });
        customerRecords.forEach(c => {
          customers[c.id] = c;
        });
      }

      const enrichedRecords = records.map(r => ({
        ...r,
        customer: customers[r.customerId] || { name: 'Unknown', phone: 'Unknown' }
      }));

      setTransactions(enrichedRecords);
    } catch (error) {
      console.error("Error fetching daily transactions:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [currentUser, refreshTrigger]);

  const toggleExpand = async (transactionId) => {
    if (expandedId === transactionId) {
      setExpandedId(null);
      return;
    }

    setExpandedId(transactionId);

    if (!itemsCache[transactionId]) {
      try {
        const items = await pb.collection('transactionItems').getFullList({
          filter: `transactionId = "${transactionId}"`,
          $autoCancel: false
        });
        setItemsCache(prev => ({ ...prev, [transactionId]: items }));
      } catch (error) {
        console.error("Error fetching items:", error);
      }
    }
  };

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this transaction?')) return;

    try {
      // Delete items first
      const items = await pb.collection('transactionItems').getFullList({
        filter: `transactionId = "${id}"`,
        $autoCancel: false
      });
      
      for (const item of items) {
        await pb.collection('transactionItems').delete(item.id, { $autoCancel: false });
      }

      // Delete transaction
      await pb.collection('transactions').delete(id, { $autoCancel: false });
      
      if (onTransactionDeleted) onTransactionDeleted();
      fetchTransactions();
    } catch (error) {
      console.error("Error deleting transaction:", error);
      alert("Failed to delete transaction");
    }
  };

  const filteredTransactions = transactions.filter(t => 
    t.customer.phone.includes(searchQuery) || 
    t.customer.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
        <h2 className="text-lg font-semibold text-gray-900">Today's Transactions</h2>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search phone or name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-gray-900"
          />
        </div>
      </div>

      <div className="overflow-y-auto flex-grow">
        {loading ? (
          <div className="p-8 text-center text-gray-500">Loading transactions...</div>
        ) : filteredTransactions.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No transactions found for today.</div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {filteredTransactions.map((transaction) => (
              <li key={transaction.id} className="hover:bg-gray-50">
                <div 
                  className="px-4 py-4 sm:px-6 cursor-pointer"
                  onClick={() => toggleExpand(transaction.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex flex-col">
                      <p className="text-sm font-medium text-indigo-600 truncate">{transaction.customer.name}</p>
                      <p className="text-xs text-gray-500">{transaction.customer.phone}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-sm font-bold text-gray-900">${transaction.totalAmount.toFixed(2)}</p>
                        <p className="text-xs font-medium text-green-600">+${transaction.totalProfit.toFixed(2)}</p>
                      </div>
                      <button 
                        onClick={(e) => handleDelete(transaction.id, e)}
                        className="text-gray-400 hover:text-red-600 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                      {expandedId === transaction.id ? (
                        <ChevronUp className="h-5 w-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-xs text-gray-500">
                        {format(new Date(transaction.created), 'h:mm a')}
                      </p>
                    </div>
                  </div>
                </div>
                
                {/* Expanded Items View */}
                {expandedId === transaction.id && (
                  <div className="px-4 pb-4 sm:px-6 bg-gray-50 border-t border-gray-100">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 mt-2">Items</h4>
                    {itemsCache[transaction.id] ? (
                      <table className="min-w-full divide-y divide-gray-200 text-sm">
                        <thead>
                          <tr>
                            <th className="text-left text-xs font-medium text-gray-500">Item</th>
                            <th className="text-right text-xs font-medium text-gray-500">Qty</th>
                            <th className="text-right text-xs font-medium text-gray-500">Price</th>
                            <th className="text-right text-xs font-medium text-gray-500">Profit</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {itemsCache[transaction.id].map(item => (
                            <tr key={item.id}>
                              <td className="py-1 text-gray-900">{item.itemName}</td>
                              <td className="py-1 text-right text-gray-600">{item.quantity}</td>
                              <td className="py-1 text-right text-gray-900">${item.sellingPrice.toFixed(2)}</td>
                              <td className="py-1 text-right text-green-600">${((item.sellingPrice - item.costPrice) * item.quantity).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <p className="text-xs text-gray-500">Loading items...</p>
                    )}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default DailyTransactionsList;